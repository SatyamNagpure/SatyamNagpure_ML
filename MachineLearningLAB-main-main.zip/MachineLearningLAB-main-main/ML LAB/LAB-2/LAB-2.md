Lab 2: Linear Regression
Objective: Build linear regression from scratch.
Description: This lab covers the basics of linear regression, including hypothesis functions, gradient descent, and the calculation of model parameters.