Lab 3: Logistic Regression & Multiclass Logistic Regression
Objective: Implement logistic regression for binary classification and extend it to multiclass classification.
Description:
Part 1: Binary logistic regression.
Part 2: Multiclass logistic regression using the one-vs-all approach to handle multiple classes.