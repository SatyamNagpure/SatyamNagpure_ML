Lab 4: Support Vector Machines (SVM)
Objective: Apply SVM for regression and classification tasks.
Description:
Part 1: Implement Support Vector Regression (SVR).
Part 2: Implement Support Vector Classification (SVC) using both linear and non-linear kernels