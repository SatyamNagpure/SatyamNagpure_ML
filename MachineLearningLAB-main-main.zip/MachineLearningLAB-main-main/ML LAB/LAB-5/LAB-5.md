Lab 5: Decision Trees
Objective: Implement decision trees for classification tasks.
Description: This lab demonstrates decision tree models, tree pruning techniques, and evaluation on different datasets.